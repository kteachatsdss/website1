===================================================================
                  LINUX CLI SCAVENGER HUNT
===================================================================

Welcome! Your mission is to navigate through 16 levels using Linux 
terminal commands. Each level contains instructions, clues, or secret 
keys that will lead you to the next step.

To start Level 1:
1. Enter the level_1 folder using the 'cd' command:
   cd level_1
2. List the contents of the folder using 'ls' to find the clue file.
3. Read the file using 'cat <filename>'.

Good luck!
